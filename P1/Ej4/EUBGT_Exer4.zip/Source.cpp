﻿#include "Program.h"

int main()
{
	Program program;
	program.run();
	return 0;
}
