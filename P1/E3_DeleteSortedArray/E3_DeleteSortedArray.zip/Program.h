// Created by eubgt on 8/11/22.

#ifndef E3_DELETESORTEDARRAY_PROGRAM_H
#define E3_DELETESORTEDARRAY_PROGRAM_H

class Program {
public:
    Program();
    void del();
};

#endif //E3_DELETESORTEDARRAY_PROGRAM_H
