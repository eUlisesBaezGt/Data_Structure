#include "Program.h"

int main() {
    //Empleando C++, construye una aplicación Orientada a Objetos, que BORRE un elemento de un arreglo.
    Program program;
    program.del();
    return 0;
}
