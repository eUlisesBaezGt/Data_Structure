#include <iostream>

using namespace std;

#include "Programs.h"

int main() {
    //Empleando C++, construye una aplicación Orientada a Objetos que:
    Programs p;
    p.First();
    cout << endl;
    p.Second();
    return 0;
}

