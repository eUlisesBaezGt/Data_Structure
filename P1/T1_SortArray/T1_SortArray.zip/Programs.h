// Created by eubgt on 8/11/22.

#ifndef T1_SORTARRAY_PROGRAMS_H
#define T1_SORTARRAY_PROGRAMS_H

class Programs {
public:
    Programs();
    void First();
    void Second();
};

#endif //T1_SORTARRAY_PROGRAMS_H
