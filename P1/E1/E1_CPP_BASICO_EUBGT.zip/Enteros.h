// Created by eubgt on 8/11/22.

#ifndef E1_ENTEROS_H
#define E1_ENTEROS_H

class Enteros {
public:
    Enteros();

    void Sumar(int &, int &);
};

#endif //E1_ENTEROS_H
