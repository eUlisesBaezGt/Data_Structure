#include <iostream>
#include "Program.h"

int main() {
    //Empleando C++, construye una aplicación Orientada a Objetos, que inserte un elemento en un arreglo ordenado.
    Program program;
    program.insert();
    return 0;
}
