// Created by eubgt on 8/16/22.

#ifndef P1TEXER2_PROGRAM_H
#define P1TEXER2_PROGRAM_H

class Program {
public:
    Program();
    void insert();
};

#endif //P1TEXER2_PROGRAM_H
